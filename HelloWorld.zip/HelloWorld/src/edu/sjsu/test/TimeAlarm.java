package edu.sjsu.test;

import java.util.Timer;

//gcm token !!!

public class TimeAlarm {
	long p=1000;
    public TimeAlarm(){
	    Timer t=new Timer();
	    Task task = new Task();
	    t.schedule(task,0,p);
    }
 
}

