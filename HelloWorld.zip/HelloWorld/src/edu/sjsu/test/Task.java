package edu.sjsu.test;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.TimerTask;

class Task extends TimerTask{
	int min,hour,date,month;
   int gmin,ghour,gdate,gmouth;
   String s="aa";   //s=getWeather().toString();
   Date d;
   /*jo=getEventDATE(userID,eventID);
    gmin=
    ghour=
    gdate=
    gmonth=
    * 
    */
	
		
	@Override
	public void run() {
		GregorianCalendar ca = new GregorianCalendar();
	    hour=ca.get(Calendar.HOUR);
	    min=ca.get(Calendar.MINUTE);
	    date=ca.get(Calendar.DATE);
	    month=ca.get(Calendar.MONTH);
		// TODO Auto-generated method stub
       if((date==gdate&&ghour == hour &&min==gmin-20)||(date==gdate&&ghour-1 == hour &&min==gmin+30)){  
       System.out.println(s);
	    }
	}
}
