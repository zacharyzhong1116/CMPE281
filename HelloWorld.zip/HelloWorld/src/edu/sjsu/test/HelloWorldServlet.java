package edu.sjsu.test;

import java.io.BufferedReader;
import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.ServletException;
import javax.servlet.http.*;

import com.google.appengine.labs.repackaged.org.json.JSONException;
import com.google.appengine.labs.repackaged.org.json.JSONObject;

@SuppressWarnings("serial")
public class HelloWorldServlet extends HttpServlet  {
	//GoogleCloudMessaging gcm;
	public void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
		resp.setContentType("application/json");
		
		JSONObject wInfo=new JSONObject();
		String uri=req.getRequestURI(); 
		String[] ua=uri.split("/");
		if(ua[ua.length-2].equals("weather")){
			if(HasDigit(ua[ua.length-1])){
				//wInfo=getWeatherByZip(ua[ua.length-1],"us"); info according to zipcode
			}
			if(!HasDigit(ua[ua.length-1])){
				//wInfo=getWeatherByCity(ua[ua.length-1]);  info according to cityname
			}else {
				resp.sendError(HttpServletResponse.SC_NOT_FOUND,"there is no such address or zipcode ");

			}
		}
		if(ua[ua.length-2].equals("calendar")){
			//wInfo=getSimpleUserCalendar((int)ua[ua.length-1]);
		}
		
		resp.getWriter().print(wInfo);
	}
	/*
	 here is for the gcm push
	 
	 */
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		resp.setContentType("application/json");
		JSONObject wInfo=new JSONObject();
		String uri=req.getRequestURI(); 
		String[] ua=uri.split("/");
		StringBuffer buffer = new StringBuffer();
		String rl = null;
		BufferedReader breader = req.getReader();
		while ((rl = breader.readLine()) != null) {
			buffer.append(rl);
		}

		if (buffer.toString().length() == 0) {
			resp.sendError(HttpServletResponse.SC_FORBIDDEN, "there is no input");
		} else {
			try {
				JSONObject json = new JSONObject(buffer.toString());
				//postCalendar(json,(int)au[au.length-1]);
				resp.getWriter().print(json);
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
	}
    
	@Override
	protected void doPut(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		resp.setContentType("application/json");
		JSONObject wInfo=new JSONObject();
		String uri=req.getRequestURI(); 
		String[] ua=uri.split("/");
		StringBuffer buffer = new StringBuffer();
		String rl = null;
		BufferedReader breader = req.getReader();
		while ((rl = breader.readLine()) != null) {
			buffer.append(rl);
		}

		if (buffer.toString().length() == 0) {
			resp.sendError(HttpServletResponse.SC_FORBIDDEN, "no content updated");
		} else {
			try {
				JSONObject json = new JSONObject(buffer.toString());
				//updateCalendar(json,(int)au[au.length-1]);
				resp.getWriter().print(json);
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		
	}
    public boolean isExist(int id){
    	boolean flag=false;
    	//if(checkById(id)){
    	//flag=true;}
    	return flag;
    }
	public boolean HasDigit(String content) {
	    boolean flag = false;
	    Pattern p = Pattern.compile(".*\\d+.*");
	    Matcher m = p.matcher(content);
	    if (m.matches()) {
	        flag = true;
	    }
	    return flag;
	}
}
